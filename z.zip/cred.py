#Twilio Details

account_sid = 'ACb9c6e2d44935a189c99e9c7c017f0bbd'
auth_token = 'd17e1fb56e2e3abed84d888c4f963291'
twilionumber = '+12398429440'
twiliosmsnumber = '+12398429440'

#FC Bot
API_TOKEN = "5882638481:AAG-GpvLyYHiky97DOCxB6veV9kg38SW00Y"

#Host URL
callurl = 'https://2d91-164-92-210-86.eu.ngrok.io'
twiliosmsurl = 'https://2d91-164-92-210-86.eu.ngrok.io/sms'









